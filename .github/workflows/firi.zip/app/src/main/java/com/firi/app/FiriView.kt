package com.firi.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.min
import kotlin.math.sin

class FiriView(context: Context) : View(context) {

    enum class Mood { IDLE, HAPPY, SURPRISED, SLEEP }

    var mood: Mood = Mood.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private val d = resources.displayMetrics.density

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 200, 255)
    }
    private val antennaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 80, 160)
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 20, 50)
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val fillDark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 20, 50)
        style = Paint.Style.FILL
    }
    private val mouthFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 30, 70)
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 16f * d
        isFakeBoldText = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val t = SystemClock.uptimeMillis()
        val w = width.toFloat()
        val h = height.toFloat()

        val speed = if (mood == Mood.SLEEP) 900.0 else 250.0
        val amp = if (mood == Mood.SLEEP) 3f * d else 5f * d
        val bounce = (sin(t / speed) * amp).toFloat()

        val cx = w / 2f
        val cy = h / 2f + bounce + 6f * d
        val r = min(w, h) * 0.34f

        // cuerpo y antena
        canvas.drawLine(cx, cy - r, cx, cy - r * 1.35f, linePaint)
        canvas.drawCircle(cx, cy - r * 1.4f, r * 0.12f, antennaPaint)
        canvas.drawCircle(cx, cy, r, bodyPaint)

        // ojos
        val ex = r * 0.42f
        val ey = cy - r * 0.1f
        val er = r * 0.17f
        val blink = (t % 3500L) < 150L

        when (mood) {
            Mood.SLEEP -> {
                canvas.drawLine(cx - ex - er, ey, cx - ex + er, ey, linePaint)
                canvas.drawLine(cx + ex - er, ey, cx + ex + er, ey, linePaint)
                canvas.drawText("z", cx + r, cy - r, textPaint)
            }
            Mood.HAPPY -> {
                val left = RectF(cx - ex - er, ey - er, cx - ex + er, ey + er)
                val right = RectF(cx + ex - er, ey - er, cx + ex + er, ey + er)
                canvas.drawArc(left, 180f, 180f, false, linePaint)
                canvas.drawArc(right, 180f, 180f, false, linePaint)
            }
            Mood.SURPRISED -> {
                canvas.drawCircle(cx - ex, ey, er * 1.3f, fillDark)
                canvas.drawCircle(cx + ex, ey, er * 1.3f, fillDark)
            }
            Mood.IDLE -> {
                if (blink) {
                    canvas.drawLine(cx - ex - er, ey, cx - ex + er, ey, linePaint)
                    canvas.drawLine(cx + ex - er, ey, cx + ex + er, ey, linePaint)
                } else {
                    canvas.drawCircle(cx - ex, ey, er, fillDark)
                    canvas.drawCircle(cx + ex, ey, er, fillDark)
                }
            }
        }

        // boca
        val my = cy + r * 0.2f
        when (mood) {
            Mood.HAPPY -> {
                val m = RectF(cx - r * 0.3f, my - r * 0.2f, cx + r * 0.3f, my + r * 0.4f)
                canvas.drawArc(m, 0f, 180f, true, mouthFill)
            }
            Mood.SURPRISED -> {
                canvas.drawCircle(cx, my + r * 0.15f, r * 0.14f, mouthFill)
            }
            Mood.SLEEP -> {
                canvas.drawLine(cx - r * 0.1f, my + r * 0.15f, cx + r * 0.1f, my + r * 0.15f, linePaint)
            }
            Mood.IDLE -> {
                val m = RectF(cx - r * 0.25f, my - r * 0.15f, cx + r * 0.25f, my + r * 0.35f)
                canvas.drawArc(m, 20f, 140f, false, linePaint)
            }
        }

        postInvalidateOnAnimation()
    }
}
