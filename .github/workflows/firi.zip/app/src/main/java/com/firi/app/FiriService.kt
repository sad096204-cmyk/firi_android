package com.firi.app

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import java.util.Random
import kotlin.math.abs

class FiriService : Service() {

    companion object {
        const val ACTION_STOP = "com.firi.app.STOP"
        private const val CHANNEL_ID = "firi_channel"
    }

    private lateinit var wm: WindowManager
    private lateinit var firi: FiriView
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private var anim: ValueAnimator? = null
    private var dragging = false
    private var attached = false
    private var sizePx = 0
    private var moodReset: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sizePx = (110 * resources.displayMetrics.density).toInt()

        firi = FiriView(this)
        params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 300
        }

        setupTouch()
        wm.addView(firi, params)
        attached = true

        handler.postDelayed({ decide() }, 3000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        anim?.cancel()
        if (attached) {
            try {
                wm.removeView(firi)
            } catch (e: Exception) {
            }
            attached = false
        }
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "FIRI", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = Intent(this, FiriService::class.java).setAction(ACTION_STOP)
        val pi = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Dormir a FIRI",
            pi
        ).build()
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("FIRI está despierto")
            .setContentText("Toca para dormirlo")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(action)
            .setOngoing(true)
            .build()
    }

    private fun safeUpdate() {
        if (attached) {
            try {
                wm.updateViewLayout(firi, params)
            } catch (e: Exception) {
            }
        }
    }

    private fun setMoodFor(mood: FiriView.Mood, ms: Long) {
        moodReset?.let { handler.removeCallbacks(it) }
        firi.mood = mood
        val r = Runnable { firi.mood = FiriView.Mood.IDLE }
        moodReset = r
        handler.postDelayed(r, ms)
    }

    private fun setupTouch() {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        firi.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    anim?.cancel()
                    dragging = true
                    moved = false
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        safeUpdate()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    if (!moved) {
                        setMoodFor(FiriView.Mood.HAPPY, 1800)
                    } else {
                        setMoodFor(FiriView.Mood.SURPRISED, 1000)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun moveTo(tx: Int, ty: Int, duration: Long) {
        val sx = params.x
        val sy = params.y
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = duration
        a.addUpdateListener { va ->
            val p = va.animatedValue as Float
            params.x = (sx + (tx - sx) * p).toInt()
            params.y = (sy + (ty - sy) * p).toInt()
            safeUpdate()
        }
        anim = a
        a.start()
    }

    private fun next(ms: Long) {
        handler.postDelayed({ decide() }, ms)
    }

    // Decisiones autónomas básicas (se ampliarán en la etapa de Autonomía)
    private fun decide() {
        if (dragging) {
            next(2000)
            return
        }
        val dm = resources.displayMetrics
        val maxX = dm.widthPixels - sizePx
        val maxY = (dm.heightPixels - sizePx).coerceAtLeast(1)

        when (rnd.nextInt(5)) {
            0, 1 -> { // caminar a un borde
                val tx = if (rnd.nextBoolean()) 0 else maxX
                val ty = rnd.nextInt(maxY)
                firi.mood = FiriView.Mood.IDLE
                moveTo(tx, ty, 2500)
                next(4500)
            }
            2 -> { // dormir
                setMoodFor(FiriView.Mood.SLEEP, 7000)
                next(9000)
            }
            3 -> { // esconderse medio fuera de pantalla
                val tx = if (params.x < dm.widthPixels / 2) -sizePx * 2 / 3 else dm.widthPixels - sizePx / 3
                firi.mood = FiriView.Mood.IDLE
                moveTo(tx, params.y, 1200)
                next(6000)
            }
            else -> { // bailar / alegrarse
                setMoodFor(FiriView.Mood.HAPPY, 3000)
                next(5000)
            }
        }
    }
}
