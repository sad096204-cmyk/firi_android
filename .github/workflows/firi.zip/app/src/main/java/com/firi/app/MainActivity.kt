package com.firi.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        val title = TextView(this).apply {
            text = "FIRI 🤖"
            textSize = 32f
        }
        val info = TextView(this).apply {
            text = "Paso 1: da el permiso de superposición.\nPaso 2: despierta a FIRI."
            textSize = 16f
        }
        val btnPerm = Button(this).apply {
            text = "1. Dar permiso de superposición"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        val btnStart = Button(this).apply {
            text = "2. Despertar a FIRI"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Primero da el permiso (botón 1)", Toast.LENGTH_LONG).show()
                } else {
                    startForegroundService(Intent(this@MainActivity, FiriService::class.java))
                }
            }
        }
        val btnStop = Button(this).apply {
            text = "Dormir a FIRI (detener)"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FiriService::class.java))
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(btnPerm)
        root.addView(btnStart)
        root.addView(btnStop)
        setContentView(root)

        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
}
